FamilyCircle v6 – professionelle Testversion

Enthalten:
- Chats als Startseite
- Feed und Einstellungen oben angeheftet
- Untere Navigation ausschließlich: Chats · Kalender · SOS · Standort · Spiele
- Spiele ganz rechts
- Größere Navigationssymbole
- Chatliste + Chatansicht mit Sprach- und Videoanruf-Demo
- Story-Erstellung (Galerie/Kamera/Text), Story-Sichtbarkeit, Reaktionen und private Antworten
- Feed-Beiträge mit Foto/Text/Album, Kommentaren, Antworten, Likes und Löschen eigener Kommentare
- Familienkalender mit Urlaub/besonderen Tagen und Sichtbarkeit pro Mitglied
- Standortfreigabe mit Empfängern und Dauer
- SOS: 8x Ja oder 8 schnelle SOS-Taps, ohne Double-Tap-Zoom
- Spiele-Hub mit Block-Blast-Platzhalter, Rangliste, manueller Score/Screenshot
- Umfangreiche Einstellungen: Profil, Familie, Sicherheit, SOS, Datenschutz, Berechtigungen, Sichtbarkeit, Benachrichtigungen, Darstellung, Export, Konto löschen
- Datenschutz-Center und Freigabe-Stopp als Demo

Wichtig:
Keine echten Nachrichten, Anrufe, Push-Mitteilungen, Standortübertragungen oder Notrufe.
