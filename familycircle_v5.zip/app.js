
const content=document.getElementById('content');
const title=document.getElementById('title');
const modal=document.getElementById('sosModal');
const navButtons=[...document.querySelectorAll('.nav-btn')];
const feedTop=document.getElementById('feedTop');
const settingsTop=document.getElementById('settingsTop');
const storyGallery=document.getElementById('storyGallery');
const storyCamera=document.getElementById('storyCamera');

let score=Number(localStorage.tapScore||0);
let yesCount=0;
let rapidSosCount=0;
let lastSosTap=0;
let currentTab='chat';
let activeChat=null;

const chats=[
  {avatar:'👩',name:'Mama',preview:'Kannst du nachher noch Brot mitbringen?',time:'12:41',badge:'2'},
  {avatar:'👨',name:'Papa',preview:'👍 Alles klar, bis später',time:'11:58',badge:''},
  {avatar:'👧',name:'Lisa',preview:'Foto',time:'10:22',badge:'1'},
  {avatar:'👦',name:'Noah',preview:'Ich bin gleich zuhause',time:'Gestern',badge:''},
  {avatar:'👨‍👩‍👧‍👦',name:'Familie',preview:'Mama: Sonntag um 14 Uhr?',time:'Gestern',badge:'4'}
];

const card=x=>`<section class="card">${x}</section>`;
const storyPeople=[
  ['👩','Mama'],['👨','Papa'],['👧','Lisa'],['👦','Noah'],['👨‍👩‍👧‍👦','Familie']
];

function storiesHtml(){
  return `<div class="stories">
    <button class="story story-create" id="createStory" style="border:0;background:none;padding:0">
      <div class="story-ring"><div>＋</div></div><div class="story-label">Story erstellen</div>
    </button>
    ${storyPeople.map((s,i)=>`<button class="story story-open" data-story="${i}" style="border:0;background:none;padding:0">
      <div class="story-ring"><div>${s[0]}</div></div><div class="story-label">${s[1]}</div>
    </button>`).join('')}
  </div>`;
}

function chatListHtml(){
  return `<div class="search">🔎 Suchen</div>${chats.map((x,i)=>`
    <div class="chatrow openable" data-chat="${i}">
      <div class="avatar">${x.avatar}</div>
      <div class="chatbody">
        <div class="line"><span class="name">${x.name}</span><span class="time">${x.time}</span></div>
        <div class="line"><span class="preview">${x.preview}</span>${x.badge?`<span class="badge">${x.badge}</span>`:''}</div>
      </div>
      <div class="quick-actions">
        <button class="icon-btn call" data-person="${i}" aria-label="Anrufen">📞</button>
        <button class="icon-btn video" data-person="${i}" aria-label="Videoanruf">🎥</button>
      </div>
    </div>`).join('')}`;
}

function feedHtml(){
  return storiesHtml()
  +card(`<div class="posthead"><div class="avatar">👩</div><div><b>Mama</b><div class="muted">Heute, 14:05</div></div></div>
    <div class="photo">👨‍👩‍👧‍👦</div><p>Sonntag zusammen ❤️</p>
    <div class="reactions"><span>❤️ 12</span><span>👍 5</span><button class="comment-trigger" data-post="0">💬 <span id="commentCount0">3</span></button></div>
    <div class="comment-panel hidden" id="comments0"></div>`)
  +card(`<div class="posthead"><div class="avatar">👨</div><div><b>Papa</b><div class="muted">Heute, 12:22</div></div></div>
    <p>Wer ist heute Abend bei Pizza dabei? 🍕</p>
    <div class="reactions"><span>❤️ 8</span><span>👍 4</span><button class="comment-trigger" data-post="1">💬 <span id="commentCount1">2</span></button></div>
    <div class="comment-panel hidden" id="comments1"></div>`);
}

function gamesHtml(){
  return card(`<h2>🎮 Spiele</h2>
    <div class="event"><span><b>Block Blast!</b><br><span class="muted">Externes Spiel · Demo</span></span><button class="primary" id="external">Spiel öffnen</button></div>
    <div class="score"><span>🥇 Lisa</span><b>48.250</b></div>
    <div class="score"><span>🥈 Papa</span><b>37.190</b></div>
    <div class="score"><span>🥉 Mama</span><b>29.820</b></div>
    <p class="muted">Highscores werden in dieser Demo nicht automatisch aus Block Blast ausgelesen.</p>`)
  +card(`<h2>Family Tap Challenge</h2><p>Dein Score: <b id="score">${score}</b></p><button class="gamebtn" id="tap">TIPP!</button>`);
}

function calendarHtml(){
  return card(`<h2>📅 Familienkalender</h2><button class="primary" id="newEvent">+ Eintrag</button>
    <div class="event"><span>🏖 Urlaub Papa <span class="pill">Mama · Lisa</span></span><span>12.–26. Aug</span></div>
    <div class="event"><span>🎂 Oma Geburtstag <span class="pill">Alle</span></span><span>Morgen</span></div>
    <div class="event"><span>⚽ Fußball Noah <span class="pill">Familie</span></span><span>Mo 17:00</span></div>
    <p class="muted">Geburtstage können später automatisch jährlich aus dem Profil übernommen werden.</p>`);
}

function mapHtml(){
  return card(`<h2>📍 Standort teilen</h2><p>Bestimme, wer deinen Live-Standort sehen darf.</p>
    <div class="check"><span>👩 Mama</span><input type="checkbox" checked></div>
    <div class="check"><span>👨 Papa</span><input type="checkbox" checked></div>
    <div class="check"><span>👧 Lisa</span><input type="checkbox"></div>
    <div class="setting"><span>Dauer</span><b>1 Stunde ›</b></div>
    <button class="primary">Standortfreigabe starten</button>`)
  +card(`<h3>Familienkarte · Demo</h3><div class="map"><span class="marker a">👩</span><span class="marker b">👨</span><span class="marker c">👧</span></div>`);
}

function settingsHtml(){
  return card(`<h2>⚙️ Einstellungen</h2>
    <div class="setting"><span>👤 Profil & Geburtstag</span><span>›</span></div>
    <div class="setting"><span>🚨 SOS-Empfänger</span><span>Mama, Papa ›</span></div>
    <div class="setting"><span>📍 Standortberechtigungen</span><span>›</span></div>
    <div class="setting"><span>🔔 Benachrichtigungen</span><span>›</span></div>`)
    +card(`<div class="notice"><b>Demo-Modus:</b> Es werden keine echten SOS-Nachrichten, Push-Mitteilungen oder Standortdaten an andere Personen gesendet.</div>`);
}

const names={chat:'Chats',feed:'Familien-Feed',games:'Spiele',calendar:'Kalender',map:'Standort',settings:'Einstellungen'};

function setActive(tab){
  navButtons.forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
  feedTop.classList.toggle('active',tab==='feed');
  settingsTop.classList.toggle('active',tab==='settings');
}

function show(tab){
  currentTab=tab; activeChat=null;
  setActive(tab);
  title.textContent=names[tab];
  if(tab==='chat') content.innerHTML=chatListHtml();
  if(tab==='feed') content.innerHTML=feedHtml();
  if(tab==='games') content.innerHTML=gamesHtml();
  if(tab==='calendar') content.innerHTML=calendarHtml();
  if(tab==='map') content.innerHTML=mapHtml();
  if(tab==='settings') content.innerHTML=settingsHtml();
  bindPageEvents();
}


const postComments={
  0:[
    {avatar:'👨',name:'Papa',text:'Tolles Foto ❤️',likes:2},
    {avatar:'👧',name:'Lisa',text:'Das war richtig schön 😊',likes:1},
    {avatar:'👦',name:'Noah',text:'Nächstes Mal wieder!',likes:0}
  ],
  1:[
    {avatar:'👩',name:'Mama',text:'Ich bin dabei 🍕',likes:1},
    {avatar:'👧',name:'Lisa',text:'Ich auch!',likes:0}
  ]
};

function renderComments(postId){
  const panel=document.getElementById(`comments${postId}`);
  if(!panel) return;
  panel.innerHTML=`<div>${postComments[postId].map((c,i)=>`
    <div class="comment-item">
      <div class="comment-avatar">${c.avatar}</div>
      <div class="comment-main">
        <div class="comment-bubble"><b>${c.name}</b><br>${c.text}</div>
        <div class="comment-meta">
          <span>gerade eben</span>
          <button data-like-comment="${postId}-${i}">Gefällt mir${c.likes?` · ${c.likes}`:''}</button>
          <button data-reply-comment="${postId}-${i}">Antworten</button>
          ${c.name==='Du'?`<button data-delete-comment="${postId}-${i}">Löschen</button>`:''}
        </div>
      </div>
    </div>`).join('')}</div>
    <div class="comment-compose">
      <input id="commentInput${postId}" placeholder="Kommentar schreiben…">
      <button data-send-comment="${postId}">Senden</button>
    </div>`;
  panel.querySelectorAll('[data-send-comment]').forEach(b=>b.onclick=()=>sendComment(Number(b.dataset.sendComment)));
  panel.querySelectorAll('[data-like-comment]').forEach(b=>b.onclick=()=>{
    const [p,i]=b.dataset.likeComment.split('-').map(Number);
    postComments[p][i].likes++; renderComments(p);
  });
  panel.querySelectorAll('[data-reply-comment]').forEach(b=>b.onclick=()=>{
    const [p,i]=b.dataset.replyComment.split('-').map(Number);
    const inp=document.getElementById(`commentInput${p}`);
    inp.value='@'+postComments[p][i].name+' '; inp.focus();
  });
  panel.querySelectorAll('[data-delete-comment]').forEach(b=>b.onclick=()=>{
    const [p,i]=b.dataset.deleteComment.split('-').map(Number);
    postComments[p].splice(i,1); renderComments(p); updateCommentCount(p);
  });
}
function sendComment(postId){
  const inp=document.getElementById(`commentInput${postId}`);
  if(!inp||!inp.value.trim()) return;
  postComments[postId].push({avatar:'🙂',name:'Du',text:escapeHtml(inp.value.trim()),likes:0});
  inp.value=''; renderComments(postId); updateCommentCount(postId);
}
function updateCommentCount(postId){
  const el=document.getElementById(`commentCount${postId}`);
  if(el) el.textContent=postComments[postId].length;
}
function openStoryViewer(i){
  const p=storyPeople[i];
  const v=document.createElement('div'); v.className='story-viewer';
  v.innerHTML=`<div class="story-progress">${Array.from({length:5},(_,x)=>`<i class="${x===i?'active':''}"></i>`).join('')}</div>
    <div class="story-view-head"><div class="avatar">${p[0]}</div><div class="story-owner"><b>${p[1]}</b><br><span class="muted">vor 12 Min</span></div><button id="closeViewer">✕</button></div>
    <div class="story-media">${p[0]}<div style="font-size:22px;margin-top:18px">Schönen Tag euch ❤️</div></div>
    <div class="story-footer">
      <div class="story-reacts">
        <button data-reaction="❤️">❤️</button><button data-reaction="😂">😂</button><button data-reaction="😍">😍</button><button data-reaction="😮">😮</button><button data-reaction="👍">👍</button>
      </div>
      <div class="story-reply"><input id="storyReply" placeholder="Antwort an ${p[1]}…"><button id="sendStoryReply">➤</button></div>
    </div>`;
  document.body.appendChild(v);
  v.querySelector('#closeViewer').onclick=()=>v.remove();
  v.querySelectorAll('[data-reaction]').forEach(b=>b.onclick=()=>{showStoryToast(`${b.dataset.reaction} an ${p[1]} gesendet`);});
  v.querySelector('#sendStoryReply').onclick=()=>{
    const inp=v.querySelector('#storyReply'); if(!inp.value.trim()) return;
    showStoryToast(`Antwort an ${p[1]} im privaten Chat gespeichert · Demo`);
    inp.value='';
  };
}
function showStoryToast(text){
  const old=document.querySelector('.story-toast'); if(old) old.remove();
  const t=document.createElement('div');t.className='story-toast';t.textContent=text;document.body.appendChild(t);
  setTimeout(()=>t.remove(),2200);
}

function bindPageEvents(){
  document.querySelectorAll('.chatrow.openable').forEach(row=>{
    row.addEventListener('click',e=>{
      if(e.target.closest('.call,.video')) return;
      openChat(Number(row.dataset.chat));
    });
  });
  document.querySelectorAll('.call').forEach(b=>b.onclick=e=>{e.stopPropagation(); startCall(Number(b.dataset.person),false)});
  document.querySelectorAll('.video').forEach(b=>b.onclick=e=>{e.stopPropagation(); startCall(Number(b.dataset.person),true)});
  const cs=document.getElementById('createStory');
  if(cs) cs.onclick=openStorySheet;
  document.querySelectorAll('.story-open').forEach(b=>b.onclick=()=>openStoryViewer(Number(b.dataset.story)));
  document.querySelectorAll('.comment-trigger').forEach(b=>b.onclick=()=>{
    const p=Number(b.dataset.post), panel=document.getElementById(`comments${p}`);
    panel.classList.toggle('hidden'); if(!panel.classList.contains('hidden')) renderComments(p);
  });
  const tap=document.getElementById('tap');
  if(tap) tap.onclick=()=>{score++;localStorage.tapScore=score;document.getElementById('score').textContent=score};
  const external=document.getElementById('external');
  if(external) external.onclick=()=>alert('Demo: Hier wird später – falls offiziell unterstützt – Block Blast geöffnet.');
  const newEvent=document.getElementById('newEvent');
  if(newEvent) newEvent.onclick=()=>alert('Nächster Ausbau: Termin/Urlaub/Geburtstag anlegen und Sichtbarkeit pro Familienmitglied wählen.');
}

function openChat(i){
  activeChat=i;
  const p=chats[i];
  title.textContent=p.name;
  content.innerHTML=`<section class="chat-screen">
    <div class="chat-top">
      <button class="back-btn" id="backChat">‹</button>
      <div class="avatar">${p.avatar}</div>
      <div class="chat-title"><b>${p.name}</b><small>online</small></div>
      <div class="chat-actions">
        <button class="icon-btn" id="voiceCall">📞</button>
        <button class="icon-btn" id="videoCall">🎥</button>
      </div>
    </div>
    <div class="messages" id="messages">
      <div class="bubble mine">Kannst du nachher noch Brot mitbringen? 😊<span class="msg-time">12:40 ✓✓</span></div>
      <div class="bubble theirs">Klar, mache ich! 🥖<span class="msg-time">12:41</span></div>
      <div class="bubble mine">Danke! ❤️<span class="msg-time">12:42 ✓✓</span></div>
      <div class="bubble theirs">Gern geschehen 😊<span class="msg-time">12:43</span></div>
    </div>
    <div class="composer">
      <button id="attachBtn">＋</button>
      <input id="msgInput" placeholder="Nachricht">
      <button id="cameraBtn">📷</button>
      <button id="micBtn">🎙️</button>
      <button class="send-btn" id="sendBtn">➤</button>
    </div>
  </section>`;
  document.getElementById('backChat').onclick=()=>show('chat');
  document.getElementById('voiceCall').onclick=()=>startCall(i,false);
  document.getElementById('videoCall').onclick=()=>startCall(i,true);
  document.getElementById('attachBtn').onclick=()=>storyGallery.click();
  document.getElementById('cameraBtn').onclick=()=>storyCamera.click();
  document.getElementById('micBtn').onclick=()=>alert('Demo: In der echten App wird hier eine Sprachnachricht aufgenommen.');
  document.getElementById('sendBtn').onclick=sendMessage;
}

function sendMessage(){
  const inp=document.getElementById('msgInput'); if(!inp||!inp.value.trim()) return;
  const m=document.getElementById('messages');
  m.insertAdjacentHTML('beforeend',`<div class="bubble mine">${escapeHtml(inp.value)}<span class="msg-time">jetzt ✓</span></div>`);
  inp.value='';
  m.scrollTop=m.scrollHeight;
}

function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}

function startCall(i,video){
  const p=chats[i];
  const d=document.createElement('div'); d.className='call-screen';
  d.innerHTML=`<div class="call-avatar">${p.avatar}</div><h2>${p.name}</h2><p>${video?'Videoanruf':'Sprachanruf'} · Demo</p>
    <div class="call-controls"><button class="call-control">🔇</button><button class="call-control">${video?'📹':'🔊'}</button><button class="call-control hangup">☎️</button></div>`;
  document.body.appendChild(d);
  d.querySelector('.hangup').onclick=()=>d.remove();
}

function openStorySheet(){
  const s=document.createElement('div'); s.className='sheet'; s.id='storySheet';
  s.innerHTML=`<div class="sheet-card">
    <div class="sheet-title"><button class="icon-btn" id="closeStory">✕</button><b>Neue Story</b><span style="width:43px"></span></div>
    <button class="sheet-option" id="galleryStory"><span class="ico">🖼️</span><span><b>Foto oder Video</b><br><span class="muted">Aus Galerie auswählen</span></span></button>
    <button class="sheet-option" id="cameraStory"><span class="ico">📷</span><span><b>Foto aufnehmen</b><br><span class="muted">Mit Kamera aufnehmen</span></span></button>
    <button class="sheet-option" id="textStory"><span class="ico">A</span><span><b>Text-Story</b><br><span class="muted">Nur Text teilen</span></span></button>
  </div>`;
  document.body.appendChild(s);
  s.querySelector('#closeStory').onclick=()=>s.remove();
  s.querySelector('#galleryStory').onclick=()=>storyGallery.click();
  s.querySelector('#cameraStory').onclick=()=>storyCamera.click();
  s.querySelector('#textStory').onclick=()=>{s.remove(); openTextStory()};
}
function openTextStory(){
  const s=document.createElement('div'); s.className='sheet';
  s.innerHTML=`<div class="sheet-card"><div class="sheet-title"><button class="icon-btn">✕</button><b>Text-Story</b><span></span></div>
    <textarea id="storyText" placeholder="Schreibe etwas..." style="width:100%;height:180px;border:0;border-radius:16px;background:#eef2ff;padding:18px;font-size:22px;resize:none"></textarea>
    <button class="primary" style="width:100%;margin-top:12px" id="publishStory">Story teilen</button></div>`;
  document.body.appendChild(s);
  s.querySelector('.icon-btn').onclick=()=>s.remove();
  s.querySelector('#publishStory').onclick=()=>{alert('Demo: Story wurde lokal simuliert.');s.remove()};
}
function fileStoryChosen(e){
  if(!e.target.files||!e.target.files[0]) return;
  document.getElementById('storySheet')?.remove();
  const name=e.target.files[0].name;
  alert(`Demo: "${name}" wurde ausgewählt. In der echten App folgt hier der Story-Editor mit Text, Zuschneiden, Zeichnen und Senden.`);
  e.target.value='';
}
storyGallery.addEventListener('change',fileStoryChosen);
storyCamera.addEventListener('change',fileStoryChosen);

function renderSOS(){
  modal.classList.remove('hidden');
  modal.innerHTML=`<div class="dialog">
    <h2>🚨 SOS auslösen?</h2>
    <p>Wollen Sie wirklich einen Alarm auslösen?</p>
    <div class="progress">Bestätigung: ${yesCount} von 8</div>
    <div class="progress-dots">${Array.from({length:8},(_,i)=>`<i class="${i<yesCount?'done':''}"></i>`).join('')}</div>
    <p class="muted">Tippe insgesamt 8× auf „Ja“. Alternativ lösen 8 schnelle Taps auf den roten SOS-Knopf den Demo-Alarm aus.</p>
    <div class="actions"><button class="no" id="sosNo">Nein</button><button class="yes" id="sosYes">Ja</button></div>
  </div>`;
  document.getElementById('sosNo').onclick=()=>{yesCount=0;modal.classList.add('hidden')};
  document.getElementById('sosYes').onclick=e=>{
    e.preventDefault();e.stopPropagation();
    yesCount++;
    if(yesCount>=8) alarm(); else renderSOS();
  };
}

function alarm(){
  yesCount=0; rapidSosCount=0;
  modal.classList.remove('hidden');
  modal.innerHTML=`<div class="dialog alarm"><h2>🚨 NOTFALL AUSGELÖST · DEMO</h2>
    <p><b>👤 Güner</b><br><span class="muted">Gerade eben</span></p>
    <div class="alarmmap">📍</div>
    <div class="event"><span>Jetzt</span><b>Aktueller Standort</b></div>
    <div class="event"><span>vor 5 Min</span><span>Letzte Position</span></div>
    <div class="event"><span>vor 10 Min</span><span>Letzte Position</span></div>
    <div class="event"><span>vor 20 Min</span><span>Letzte Position</span></div>
    <div class="event"><span>vor 1 Std</span><span>Letzte Position</span></div>
    <p class="notice">Testmodus: Es wurde niemand benachrichtigt und kein Standort übertragen.</p>
    <button class="primary" id="closeAlarm">Demo schließen</button></div>`;
  document.getElementById('closeAlarm').onclick=()=>modal.classList.add('hidden');
}

document.getElementById('sosBtn').onclick=e=>{
  e.preventDefault();e.stopPropagation();
  const now=Date.now();
  rapidSosCount = (now-lastSosTap<1100) ? rapidSosCount+1 : 1;
  lastSosTap=now;
  if(rapidSosCount>=8){alarm();return}
  renderSOS();
};

navButtons.forEach(b=>b.onclick=()=>show(b.dataset.tab));
feedTop.onclick=()=>show('feed');
settingsTop.onclick=()=>show('settings');

if('serviceWorker'in navigator) navigator.serviceWorker.register('sw.js');
show('chat');
